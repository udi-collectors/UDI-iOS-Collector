//  Copyright (c) Experian, 2023. All rights reserved.
//
//  UDICollector.h
//  UDICollector
//
//  Created by Snehi Yavanam on 3/13/23.
//

#import <Foundation/Foundation.h>

//! Project version number for UDICollector.
FOUNDATION_EXPORT double UDICollectorVersionNumber;

//! Project version string for UDICollector.
FOUNDATION_EXPORT const unsigned char UDICollectorVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <UDICollector/PublicHeader.h>
//@class UDICollector

